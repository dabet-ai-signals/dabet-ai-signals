import React from "react";
import ReactDOM from "react-dom/client";

function App() {
  return (
    <div style={{
      fontFamily: "Arial, sans-serif",
      textAlign: "center",
      padding: "30px",
      backgroundColor: "#0e1117",
      color: "#00ff99",
      minHeight: "100vh"
    }}>
      <h1>📊 Dabet AI Signals</h1>
      <p>Real-time Binary Trading Signal Viewer</p>
      <div style={{
        marginTop: "50px",
        border: "2px solid #00ff99",
        borderRadius: "15px",
        padding: "20px",
        display: "inline-block",
        backgroundColor: "#1b1f27"
      }}>
        <h2>🔥 EUR/USD Signal</h2>
        <p>Next Candle Prediction: <b style={{color: "#FFD700"}}>BUY ↑</b></p>
        <p>Timeframe: 1 Minute</p>
      </div>
      <footer style={{marginTop: "50px", fontSize: "12px", color: "#888"}}>
        Powered by Dabet AI • Finorex System
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
