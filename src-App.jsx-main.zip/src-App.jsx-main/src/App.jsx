import React from "react";

export default function App() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-950 text-green-400 text-center">
      <h1 className="text-3xl font-bold mb-2">📊 Dabet AI Signals</h1>
      <p className="text-sm mb-8 text-gray-400">
        Real-time Binary Trading Signal Viewer
      </p>

      <div className="border-2 border-green-400 rounded-2xl p-6 bg-gray-900 shadow-lg">
        <h2 className="text-xl font-semibold text-white">🔥 EUR/USD Signal</h2>
        <p className="mt-2">
          Next Candle Prediction:{" "}
          <b className="text-yellow-400">BUY ↑</b>
        </p>
        <p className="text-sm text-gray-400 mt-1">Timeframe: 1 Minute</p>
      </div>

      <footer className="mt-10 text-xs text-gray-500">
        Powered by Dabet AI • Finorex System
      </footer>
    </div>
  );
}
